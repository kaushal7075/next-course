"use client";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function ReactToast() {
  return (
    <div>
      <ToastContainer />
    </div>
  );
}

export default ReactToast;
