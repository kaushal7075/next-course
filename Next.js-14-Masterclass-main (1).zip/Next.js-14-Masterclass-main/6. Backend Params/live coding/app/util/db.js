export const users = [
  {
    id: "1",
    name: "Alex Merson",
    age: 28,
    email: "alexmerson@gmail.com",
    password: "alexmerson12",
  },
  {
    id: "2",
    name: "Quagmire",
    age: 25,
    email: "quagmire@gmail.com",
    password: "quagmire123",
  },
  {
    id: "3",
    name: "Jordan",
    age: 21,
    email: "jordan@gmail.com",
    password: "jordan123",
  },
  {
    id: "4",
    name: "Mike",
    age: 18,
    email: "mike@gmail.com",
    password: "mike123",
  },
  {
    id: "5",
    name: "Tony",
    age: 45,
    email: "tony@gmail.com",
    password: "tony123",
  },
  {
    id: "6",
    name: "meh",
    email: "meh@gmail.com",
    password: "meh",
  },
];
