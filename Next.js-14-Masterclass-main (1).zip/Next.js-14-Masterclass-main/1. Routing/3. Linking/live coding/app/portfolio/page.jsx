const Portfolio = () => {
  return <h1>This is Portfolio Page</h1>;
};

export default Portfolio;
