const About = () => {
  return <h1>User redirected to About Page</h1>;
};
export default About;
