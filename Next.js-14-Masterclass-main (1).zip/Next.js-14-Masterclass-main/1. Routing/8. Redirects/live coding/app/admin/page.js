const Page = () => {
  return <div>Admin Page</div>;
};

export default Page;
