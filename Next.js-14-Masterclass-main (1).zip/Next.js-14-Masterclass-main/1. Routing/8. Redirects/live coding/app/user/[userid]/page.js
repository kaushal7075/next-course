const Page = () => {
  return <div>User Details Page</div>;
};

export default Page;
