const Projects = () => {
  return <h1>This is User Projects Page</h1>;
};

export default Projects;
