const Users = () => {
  return <h1>This is Users Page</h1>;
};

export default Users;
