export default function Home() {
  return <main>Next.js Complete Course</main>;
}
