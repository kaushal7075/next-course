const AboutStudent = () => {
  return <div>AboutStudent</div>;
};

export default AboutStudent;
