const AboutCollege = () => {
  return <div>AboutCollege</div>;
};

export default AboutCollege;
