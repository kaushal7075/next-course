const LoginStudent = () => {
  return <div>LoginStudent</div>;
};
export default LoginStudent;
