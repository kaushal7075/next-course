const LoginTeacher = () => {
  return <div>LoginTeacher</div>;
};

export default LoginTeacher;
