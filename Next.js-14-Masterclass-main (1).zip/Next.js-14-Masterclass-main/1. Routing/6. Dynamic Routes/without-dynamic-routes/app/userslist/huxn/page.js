"use client";

const HuXn = () => {
  return (
    <div>
      <h1>Info About HuXn</h1>
      <p>Hello I'm HuXn</p>
    </div>
  );
};

export default HuXn;
