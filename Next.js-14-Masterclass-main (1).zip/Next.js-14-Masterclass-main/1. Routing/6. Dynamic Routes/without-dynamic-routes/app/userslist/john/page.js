"use client";

const John = () => {
  return (
    <div>
      <h1>Info About John</h1>
      <p>Hello I'm John</p>
    </div>
  );
};

export default John;
