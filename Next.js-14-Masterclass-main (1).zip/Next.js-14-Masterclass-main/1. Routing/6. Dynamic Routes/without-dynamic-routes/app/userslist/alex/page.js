"use client";

const Alex = () => {
  return (
    <div>
      <h1>Info About Alex</h1>
      <p>Hello I'm Alex</p>
    </div>
  );
};

export default Alex;
