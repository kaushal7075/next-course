"use client";

const Jordan = () => {
  return (
    <div>
      <h1>Info About Jordan</h1>
      <p>Hello I'm Jordan</p>
    </div>
  );
};

export default Jordan;
