const Login = () => {
  return <h1>This is Login Page</h1>;
};

export default Login;
