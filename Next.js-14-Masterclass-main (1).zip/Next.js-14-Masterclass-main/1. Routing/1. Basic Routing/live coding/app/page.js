export default function Home() {
  return <h1>Next.js Complete Course 🤜</h1>;
}
