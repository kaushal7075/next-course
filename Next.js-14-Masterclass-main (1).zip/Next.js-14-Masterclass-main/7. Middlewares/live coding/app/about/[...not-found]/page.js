const AboutPageNotFound = () => {
  return <h1>This about page is not avaliable</h1>;
};

export default AboutPageNotFound;
