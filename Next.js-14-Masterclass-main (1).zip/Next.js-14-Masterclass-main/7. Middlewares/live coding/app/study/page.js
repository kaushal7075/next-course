const Study = () => {
  return <div>Study</div>;
};

export default Study;
