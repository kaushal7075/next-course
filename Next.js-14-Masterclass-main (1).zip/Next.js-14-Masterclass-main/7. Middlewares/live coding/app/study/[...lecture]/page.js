"use client";

const Lecture = ({ params }) => {
  // console.log(params);

  return <div>Lecture {params.lecture}</div>;
};

export default Lecture;
