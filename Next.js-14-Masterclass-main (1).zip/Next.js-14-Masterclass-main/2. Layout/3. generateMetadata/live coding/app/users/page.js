const Users = () => {
  return <h1>Users Page</h1>;
};

export default Users;

export const generateMetadata = () => {
  return {
    title: "Users Details",
    description: "All about users details",
  };
};
