const LoginStudent = () => {
  return <h1>Login Regular User 👤 </h1>;
};
export default LoginStudent;
