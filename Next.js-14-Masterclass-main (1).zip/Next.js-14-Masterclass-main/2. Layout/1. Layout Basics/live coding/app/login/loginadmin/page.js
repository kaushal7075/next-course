const LoginTeacher = () => {
  return <h1>Login As Admin</h1>;
};

export default LoginTeacher;
